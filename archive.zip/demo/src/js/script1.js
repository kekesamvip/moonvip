console.log("a");
function test(){

}
test();