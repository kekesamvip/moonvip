/*!gruntProject-1.0.0-2016-02-25*/console.log("a");
function test(){

}
test();
console.log("b");
function sum(){
	return 100;
}
sum();