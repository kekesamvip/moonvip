console.log("b");
function sum(){
	return 100;
}
sum();